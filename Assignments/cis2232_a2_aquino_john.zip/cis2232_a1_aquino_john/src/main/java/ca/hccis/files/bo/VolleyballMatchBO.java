package ca.hccis.files.bo;

import ca.hccis.files.entity.VolleyballMatch;

/**
 * Determines which player won three of the five recorded games.
 * @author John Aquino
 * @since 2026-09-29
 */
public class VolleyballMatchBO {
    private static final int GAMES_TO_WIN = 3;

    /**
     * Counts a game win for the player with the higher score; ties count
     * for neither player. No minimum points or winning margin is imposed.
     * Null or any negative score yields no valid winner. The entity is
     * not changed; the controller uses the result to store winnerName.
     *
     * @param match entity with the five recorded pairs of scores
     * @return 1.0 for player 1, 2.0 for player 2, or 0.0 if neither wins three
     */
    public double calculate(VolleyballMatch match) {
        if (match == null) { return 0.0; }
        int[][] games = {
            {match.getPlayer1Game1Score(), match.getPlayer2Game1Score()},
            {match.getPlayer1Game2Score(), match.getPlayer2Game2Score()},
            {match.getPlayer1Game3Score(), match.getPlayer2Game3Score()},
            {match.getPlayer1Game4Score(), match.getPlayer2Game4Score()},
            {match.getPlayer1Game5Score(), match.getPlayer2Game5Score()}
        };
        int player1Wins = 0;
        int player2Wins = 0;
        for (int[] game : games) {
            if (game[0] < 0 || game[1] < 0) { return 0.0; }
            if (game[0] > game[1]) {
                player1Wins++;
            } else if (game[1] > game[0]) {
                player2Wins++;
            }
        }
        if (player1Wins >= GAMES_TO_WIN) {
            return 1.0;
        }
        if (player2Wins >= GAMES_TO_WIN) {
            return 2.0;
        }
        return 0.0;
    }
}
